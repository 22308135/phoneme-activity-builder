/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 66.05944391179291, "KoPercent": 33.940556088207096};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4928092042186002, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.6493506493506493, 500, 1500, "04 Read saved activity"], "isController": false}, {"data": [0.6610169491525424, 500, 1500, "05 Generate activity HTML"], "isController": false}, {"data": [0.24107142857142858, 500, 1500, "03 Save activity"], "isController": false}, {"data": [0.16666666666666666, 500, 1500, "07 Read dashboard metrics"], "isController": false}, {"data": [0.33189655172413796, 500, 1500, "02 Load dictionary"], "isController": false}, {"data": [1.0, 500, 1500, "01 Open builder"], "isController": false}, {"data": [0.6140350877192983, 500, 1500, "06 Delete test activity"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1043, 354, 33.940556088207096, 5792.985618408432, 2, 15017, 1318.0, 15009.0, 15012.0, 15015.56, 14.259347870667852, 71.00559302156675, 2.4546838685145946], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["04 Read saved activity", 77, 20, 25.974025974025974, 4594.441558441557, 3, 15013, 27.0, 15007.0, 15008.1, 15013.0, 1.1326361002015208, 1.4834677189517966, 0.1374568136519424], "isController": false}, {"data": ["05 Generate activity HTML", 59, 11, 18.64406779661017, 3655.7457627118647, 10, 15014, 180.0, 15006.0, 15008.0, 15014.0, 0.8719168871089306, 4.4817936549573645, 0.12251228904044807], "isController": false}, {"data": ["03 Save activity", 224, 147, 65.625, 9678.15178571429, 9, 15015, 11167.5, 15011.0, 15012.0, 15014.5, 3.5988560778895278, 5.337705925058643, 1.2109990038880498], "isController": false}, {"data": ["07 Read dashboard metrics", 162, 135, 83.33333333333333, 11462.462962962962, 5, 15017, 15006.0, 15014.0, 15016.0, 15017.0, 2.274865544212433, 4.878890507175656, 0.11694669512588994], "isController": false}, {"data": ["02 Load dictionary", 232, 25, 10.775862068965518, 5133.909482758621, 2, 15016, 4324.5, 15002.0, 15006.7, 15014.0, 3.1944482692148815, 8.645481215404951, 0.45926379240905457], "isController": false}, {"data": ["01 Open builder", 232, 0, 0.0, 44.40086206896553, 4, 178, 13.0, 147.70000000000002, 159.35, 176.67, 4.0082930200414655, 59.54662394177608, 0.6244229710176227], "isController": false}, {"data": ["06 Delete test activity", 57, 16, 28.07017543859649, 4323.333333333333, 7, 15015, 165.0, 15007.4, 15010.3, 15015.0, 1.3125777184175378, 0.8167629991249481, 0.2006601387993368], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 25, 7.062146892655368, 2.3969319271332696], "isController": false}, {"data": ["500/Internal Server Error", 57, 16.10169491525424, 5.465004793863854], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 272, 76.8361581920904, 26.07861936720997], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1043, 354, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 272, "500/Internal Server Error", 57, "503/Service Unavailable", 25, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["04 Read saved activity", 77, 20, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 20, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["05 Generate activity HTML", 59, 11, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 11, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["03 Save activity", 224, 147, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 96, "500/Internal Server Error", 51, "", "", "", "", "", ""], "isController": false}, {"data": ["07 Read dashboard metrics", 162, 135, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 110, "503/Service Unavailable", 25, "", "", "", "", "", ""], "isController": false}, {"data": ["02 Load dictionary", 232, 25, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 25, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["06 Delete test activity", 57, 16, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 10, "500/Internal Server Error", 6, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
