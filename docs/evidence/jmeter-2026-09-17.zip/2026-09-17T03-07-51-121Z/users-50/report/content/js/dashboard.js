/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 83.80281690140845, "KoPercent": 16.197183098591548};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7319542253521126, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.923728813559322, 500, 1500, "04 Read saved activity"], "isController": false}, {"data": [0.8220338983050848, 500, 1500, "05 Generate activity HTML"], "isController": false}, {"data": [0.5728643216080402, 500, 1500, "03 Save activity"], "isController": false}, {"data": [0.4883720930232558, 500, 1500, "07 Read dashboard metrics"], "isController": false}, {"data": [0.616504854368932, 500, 1500, "02 Load dictionary"], "isController": false}, {"data": [1.0, 500, 1500, "01 Open builder"], "isController": false}, {"data": [0.8043478260869565, 500, 1500, "06 Delete test activity"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1136, 184, 16.197183098591548, 2510.605633802817, 2, 15018, 19.5, 10964.1, 11616.049999999994, 15008.26, 16.55252804895818, 69.90501318209967, 3.823847647712371], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["04 Read saved activity", 118, 0, 0.0, 500.6694915254237, 2, 10004, 6.5, 75.50000000000004, 5121.399999999997, 9960.300000000001, 2.095393685406826, 1.7468319378840076, 0.3440183058386902], "isController": false}, {"data": ["05 Generate activity HTML", 118, 6, 5.084745762711864, 1668.9830508474574, 9, 15009, 70.5, 6286.500000000043, 15002.05, 15008.62, 1.7543859649122808, 9.742292619127266, 0.2879451011002081], "isController": false}, {"data": ["03 Save activity", 199, 71, 35.678391959798994, 4554.683417085428, 9, 15009, 123.0, 11278.0, 12126.0, 15006.0, 2.9304352948106263, 2.13516989437916, 1.65967305950698], "isController": false}, {"data": ["07 Read dashboard metrics", 172, 84, 48.83720930232558, 5696.0988372093025, 5, 15018, 5717.5, 12377.100000000002, 15007.05, 15017.27, 2.579638850560922, 3.402912264158018, 0.37951718009478674], "isController": false}, {"data": ["02 Load dictionary", 206, 2, 0.970873786407767, 2321.3883495145633, 2, 15013, 19.0, 5856.2, 7336.949999999987, 14654.050000000034, 3.253213732983797, 8.838166681800953, 0.5191101631344556], "isController": false}, {"data": ["01 Open builder", 208, 0, 0.0, 13.639423076923086, 3, 108, 10.0, 17.0, 25.0, 104.72999999999999, 3.5735147579287356, 52.87060988128371, 0.5565329121997732], "isController": false}, {"data": ["06 Delete test activity", 115, 21, 18.26086956521739, 1990.217391304348, 7, 15006, 24.0, 10062.800000000001, 13634.99999999998, 15006.0, 2.9008172737362528, 0.8833254638154576, 0.5149837459640804], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 70, 38.04347826086956, 6.161971830985915], "isController": false}, {"data": ["500/Internal Server Error", 80, 43.47826086956522, 7.042253521126761], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 34, 18.47826086956522, 2.992957746478873], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1136, 184, "500/Internal Server Error", 80, "503/Service Unavailable", 70, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 34, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["05 Generate activity HTML", 118, 6, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 6, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["03 Save activity", 199, 71, "500/Internal Server Error", 64, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 7, "", "", "", "", "", ""], "isController": false}, {"data": ["07 Read dashboard metrics", 172, 84, "503/Service Unavailable", 70, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 14, "", "", "", "", "", ""], "isController": false}, {"data": ["02 Load dictionary", 206, 2, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["06 Delete test activity", 115, 21, "500/Internal Server Error", 16, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 5, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
