# JMeter load-test results

Run started: 2026-09-17T03:07:51.124Z

Environment: Windows_NT 10.0.26200 x64; Intel(R) Core(TM) Ultra 5 125H; 18 logical processors; 15.47 GiB RAM. Node v24.15.0, Next.js 16.3.2, JMeter 5.6.3.

The production app and JMeter ran on the same machine against a fresh, seeded SQLite database for every stage. Smoke testing is separate from the measured load stages. Each measured stage is 60 seconds including a 10-second ramp-up, with a 200 ms pause before each HTTP request. Users alternate Wordle and Word Search workflows. There is one run at each load level.

| Concurrent users | Requests | Errors | Error % | Mean (ms) | p95 (ms) | Requests/s | Wordle / Search outputs |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 259 | 0 | 0 | 17.77 | 36 | 4.43 | 18 / 19 |
| 10 | 2508 | 0 | 0 | 14.59 | 34 | 42.85 | 180 / 179 |
| 25 | 5970 | 0 | 0 | 25.24 | 76 | 102.09 | 425 / 426 |
| 50 | 1136 | 184 | 16.2 | 2510.61 | 11609 | 16.55 | 56 / 56 |
| 100 | 1043 | 354 | 33.94 | 5792.99 | 15012 | 14.26 | 23 / 25 |

Mean and p95 cover individual HTTP samples, including failed samples, not a complete user journey. p95 uses the nearest-rank method. Throughput divides sample count by the measured interval from the earliest sample start to the latest sample end. Native JMeter reports may use slightly different percentile interpolation. Requests still in flight at the schedule boundary can make the observed interval slightly longer than 60 seconds; a final user journey may be incomplete.

## Evidence

- [smoke: native JMeter report](smoke/report/index.html) · [raw samples](smoke/results.jtl) · [server health and dashboard after load](smoke/after.json)
- [users-1: native JMeter report](users-1/report/index.html) · [raw samples](users-1/results.jtl) · [server health and dashboard after load](users-1/after.json)
- [users-10: native JMeter report](users-10/report/index.html) · [raw samples](users-10/results.jtl) · [server health and dashboard after load](users-10/after.json)
- [users-25: native JMeter report](users-25/report/index.html) · [raw samples](users-25/results.jtl) · [server health and dashboard after load](users-25/after.json)
- [users-50: native JMeter report](users-50/report/index.html) · [raw samples](users-50/results.jtl) · [server health and dashboard after load](users-50/after.json)
- [users-100: native JMeter report](users-100/report/index.html) · [raw samples](users-100/results.jtl) · [server health and dashboard after load](users-100/after.json)

## Limits

Single local machine runs client and server. HTTP requests only: no JavaScript execution, rendering, offline gameplay or human think-time model. 60-second stages include 10-second ramp-up. One run per level; results do not establish production capacity. Current working-tree source was built, not necessarily committed HEAD.
These staged levels are an equivalent local load progression, not evidence of 1,000 or 10,000 concurrent users. JMeter does not execute the page-time tracker or play downloaded games. HTML responses and stored IPA data are asserted; browser behaviour remains a Playwright responsibility.


